﻿using System;

namespace NaughtyAttributes
{
    public class SpecialCaseDrawerAttribute : Attribute, INaughtyAttribute
    {
    }
}
